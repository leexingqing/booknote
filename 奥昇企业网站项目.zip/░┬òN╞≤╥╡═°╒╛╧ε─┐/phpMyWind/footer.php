<!-- 底部 -->
<div class="footer">
	<div class="container">
    	<div class="row">

			<div class="col-lg-8 col-md-8">
			    <div class="f-content">
				<ul>
					<li><img src="images/header-logo.png" alt=""></li>
					<li>合作热线：4008745099 18307459777 公司地址：湖南省长沙市鹤城区河西市政府大楼</li>
					<li><?php echo $cfg_copyright; ?></li>
					<li>本栏目文字内容归aorise.cn 所有,任何单位及个人未经许可，不得擅自转摘使用</li>
				</ul>
			    </div>
			   </div>

			<div class="col-lg-4 col-md-4">
			    <div class="f-img">
			    	<img src="images/scanCode.PNG" alt=""/>
			    </div>
			</div>

	</div>
  </div>
</div>	

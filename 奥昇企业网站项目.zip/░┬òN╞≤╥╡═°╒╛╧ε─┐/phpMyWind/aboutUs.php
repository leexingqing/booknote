<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 8 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="CSS/aboutus.css"/>
<link rel="stylesheet" href="CSS/head-common.css"/>
<link rel="stylesheet" href="CSS/footer-common.css"/>
<link rel="stylesheet" href="CSS/base.css"/>
<link rel="stylesheet" href="CSS/bootstrap.min.css"/>
<script src="JS/jquery.min.js""></script>
<script src="JS/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".caselist a.img img").LoadImage({width:100,height:80});
});
</script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->

<!-- 头部图片 -->
	<div class="nav-content">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="nav-img">
						<img src="images/15.jpg" alt=""/>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- start 导航位置 -->
	<div class="common">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="common-title">
	 					<?php echo GetCatName($cid); ?>
	 					</div>
			<div class="common-content">
				您当前所在位置:<?php echo GetPosStr($cid); ?>
			</div>
			<div class="common-wrap"></div>
				</div>
			</div>
		</div>
	</div> 

<div class="position">
	<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="position-title"><?php echo GetCatName($cid); ?></div>
					<div class="position-wrap"></div>
			</div>
		</div>
	</div>
</div> 
<!-- end 导航位置 -->

<!-- mainbody-->
<div class="aboutus-content">
	<div class="container">
	    <div class="row">

			<div class="col-lg-3 col-md-3">
				<div class="left-aside">
					<div class="left-head">
						<h4>关于我们/Aboout us</h4>
					</div>
						<div class="left-nav">
						<ul>
							<li><a href="aboutus.php">公司简介</a></li>
							<li><a href="aboutUs-honnor.php">荣誉资质</a></li>
							<li><a href="aboutus-corporatecultuer.html">企业文化</a></li>
							<li><a href="aboutus-chairman.html">董事长致辞</a></li>
							<li><a href="#">公司风采</a></li>
							<li><a href="#">合作伙伴</a></li>
							<li><a href="#">公司地址</a></li>
						</ul>
					</div>
			</div>
		</div>

<div class="col-lg-9 col-md-9">
			<div class="right-content">

			<?php
			$dosql->Execute("SELECT * FROM pmw_infolist WHERE classid=22 AND delstate='' AND checkinfo=true ORDER BY orderid DESC   LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>

				<p>
						<?php echo $row['content']; ?>
				</p>
				</div>
			</div>
					<?php
			         }
			         ?>
		</div>
	</div>
</div>


<!-- /mainbody-->
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>
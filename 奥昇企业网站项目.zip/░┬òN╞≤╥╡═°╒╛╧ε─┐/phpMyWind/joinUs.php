<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,0,0,'人才招聘'); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" href="CSS/joinUs.css"/>
	<link rel="stylesheet" href="CSS/head-common.css"/>
    <link rel="stylesheet" href="CSS/footer-common.css"/>
    <link rel="stylesheet" href="CSS/base.css"/>
    <link rel="stylesheet" href="CSS/bootstrap.min.css"/>
    <script src="JS/jquery.min.js""></script>
    <script src="JS/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->

<!-- 头部图片 -->
    <div class="nav-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="nav-img">
                        <img src="images/16.jpg" alt=""/>
                    </div>
                </div>
            </div>
        </div>
    </div>




<!-- start 导航位置 -->
    <div class="common">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                <div class="common-title">
                    加入奥晟
                    </div>
                        <div class="common-content">
                            您当前所在位置:>
                            <a href="index.html">首页</a>>
                            <a href="joinUs.html">加入奥晟</a>>
                        </div>
                        <div class="common-wrap"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="position">
        <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="position-title">加入奥晟</div>
                        <div class="position-wrap"></div>
                </div>
            </div>
        </div>
    </div>          
<!-- end 导航位置 -->


<!-- mainbody -->
<div class="container">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="foreword">
                <h3>前言</h3>
                <p>湖南奥昇信息技术有限公司专注于教育、医疗卫生等领域的软硬件开发、生产、销售、运营服务及相关大数据开发应用，为客户提供“软件+硬件+运营服务+资金”的专业综合性解决方案。
                目前，公司已拥有几十项相关软件著作权，现又与多所高校及企事业单位形成产、学、研深度合作模式，助力创新研发生产、实践创新运营服务，旨在为教育、医疗卫生等领域提供一流的产品和服务。</p>
                <form class="form-inline" method="post">
                    <div class="form-serach">
                  <label>请输入职位</label>
                  <input type="text" id="" name="" placeholder=" 关键字..." value="">
                    </div>
                    <button type="submit">搜索</button>
                </form>
            </div>

		<?php
			$dosql->Execute("SELECT * FROM pmw_infolist WHERE classid=23");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>

		<div class="list-group">
				    <ul>
				        <li>
			                <div class="list-group-title">
			                    <h2><?php echo $row['title']; ?></h2>
			                </div>
			                <div class="list-group-depict">
			                <p>
			                  <span> <?php echo $row['content']; ?></span>
			                  </p>
			                </div>
			                <div class="list-group-inform">
			                    <kbd>发布时间：</kbd>&nbsp;&nbsp;<i>2015-09-15</i>&nbsp;&nbsp;有效时间：<label>不限</label>
			                </div>
			                </li>
			        </ul>
			        </div>

					<?php
			         }
			         ?>


				<div class="page_info">共<span>  1  </span> 页 <span> 7 </span>条记录</div>

        </div>
    </div>
</div>

<!-- /mainbody-->


<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>
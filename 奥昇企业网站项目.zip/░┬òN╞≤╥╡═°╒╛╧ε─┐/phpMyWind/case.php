<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 5 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" href="CSS/case.css"/>
    <link rel="stylesheet" href="CSS/head-common.css"/>
    <link rel="stylesheet" href="CSS/footer-common.css"/>
    <link rel="stylesheet" href="CSS/base.css"/>
    <link rel="stylesheet" href="CSS/bootstrap.min.css"/>
    <script src="JS/jquery.min.js""></script>
    <script src="JS/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".product_list li img").LoadImage({width:220,height:150});
});
</script>
</head>
<body>

<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->

<!-- 头部图片 -->
<div class="nav-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="nav-img">
                        <img src="images/9.jpg" alt=""/>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!-- start 导航位置 -->
<div class="common">
    <div class="container">
            <div class="row">
             <div class="col-lg-12 col-md-12">
                 <div class="common-title">
					<?php echo GetCatName($cid); ?>
				 </div>
                        <div class="common-content">
							您当前所在位置:<a href="index.php"><?php echo GetPosStr($cid); ?></a>
					 </div>
                      <div class="common-wrap"></div>
             </div>
        </div>
    </div>
</div>  
<div class="position">          
  <div class="container">
         <div class="row">
             <div class="col-lg-12 col-md-12">             
                    <div class="position-title">
                         <a href="case.html"><?php echo GetCatName($cid); ?></a>
                    </div>
                    <div class="position-wrap"></div>
            </div>
        </div>
    </div>
</div>
<!-- end 导航位置 -->

<!-- /mainbody-->
	<div class="c-content">
		<div class="container">
			<div class="row">
						<?php
						if(!empty($keyword))
						{
							$keyword = htmlspecialchars($keyword);

							$sql = "SELECT * FROM `#@__infoimg` WHERE (classid=$cid OR parentstr LIKE '%,$cid,%') AND title LIKE '%$keyword%' AND delstate='' AND checkinfo=true ORDER BY orderid DESC";
						}
						else
						{
							$sql = "SELECT * FROM pmw_infoimg WHERE classid=21";
						}

						$dopage->GetPage($sql,9);
						while($row = $dosql->GetArray())
						{
							if($row['picurl'] != '') $picurl = $row['picurl'];
							else $picurl = 'templates/default/images/nofoundpic.gif';
							
							if($row['linkurl']=='' and $cfg_isreurl!='Y') $gourl = 'productshow.php?cid='.$row['classid'].'&id='.$row['id'];
							else if($cfg_isreurl=='Y') $gourl = 'productshow-'.$row['classid'].'-'.$row['id'].'-1.html';
							else $gourl = $row['linkurl'];
						?>
						<div class="col-lg-4 col-md-4 col-xs-4">
							<div class="c-img-text">
								<div class="img">
									<a href="<?php echo $gourl; ?>" class="img"><img src="<?php echo $picurl; ?>" />
									</a>
								</div>
								<div class="text">
									<a href="<?php echo $gourl; ?>"><?php echo ReStrLen($row['title'],10); ?>
									</a>
								</div>
							</div>
						</div>
						<?php
						}
						?>
					</div>
				</div>
			</ul>
		</div>
	</div>
<!-- /mainbody-->

<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>
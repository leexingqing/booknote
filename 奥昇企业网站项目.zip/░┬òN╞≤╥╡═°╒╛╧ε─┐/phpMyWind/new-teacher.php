<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 16 : intval($cid);
$cid = empty($id) ? 11 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="CSS/solution-details.css"/>
<link rel="stylesheet" href="CSS/footer-common.css"/>
  <link rel="stylesheet" href="CSS/base.css"/>
  <link rel="stylesheet" href="CSS/bootstrap.min.css"/>
  <script src="JS/jquery.min.js""></script>
  <script src="JS/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".softlist li img").LoadImage({width:50,height:50});
});
</script>
</head>
<body>
 
<!-- banner-->
<div class="container"> 
  <div class="row">
     <div class="col-lg-12 col-md-12">
        <div class="banner">
            <div class="nav-img">
                <img src="images/detailsNav.jpg" alt="" />
            </div>
        </div>
      </div>
  </div>
</div>

<!-- /banner--> 

<!-- start 导航位置 -->
  <div class="common">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
              <div class="common-title">
             <?php echo GetCatName($cid); ?>
          </div>
          <div class="common-content">
            您当前所在位置：<a href="index.php"><?php echo GetPosStr($cid); ?></a>
          </div>
          <div class="common-wrap"></div>
         </div>
       </div>
   </div>
</div>

<!-- mainbody-->
<div class="container">
      <div class="row">

         <?php
            $dosql->Execute("SELECT * FROM pmw_infolist where classid=16 and id=53 ");
            while($row = $dosql->GetArray())
            {
              if($row['linkurl'] != '')$gourl = $row['linkurl'];
              else $gourl = 'javascript:;';
            ?>


        <div class="col-lg-12 col-md-12">
            <h1 class="title"><a href="<?php echo $gourl; ?>"><?php echo $row['title']; ?></a></h1>
              <div class="info">
                  <span>更新时间：</span>2017-03-28 15:33:48<span>&nbsp;点击次数：</span>593次
                </div>
                 <div class="desc">
                 <?php echo $row['description']; ?>
                </div>
                <div>
                <img src="<?php echo $row['picurl']; ?>"/>
                </div>
            <div id="textarea">
                <div class="text" style="visibility:visible;">
                  <p>
                    <span><?php echo $row['content']; ?></span>
                  </p>
                   </div>      
            </div>
        </div>

              <?php
                       }
                       ?>
    <div class="author"> (编辑：admin)</div>
        <div class="preNext">
            <div class="line"><strong></strong></div>

                <ul class="text">
                <li>上一篇：<a href="solution-details.php"> 湖南奥昇信息互联网+监督 项目介绍</a></li><li>下一篇：<a href="new-education.php">教师的“铁饭碗”将不保？各省份将破除教师资格“终身制”？</a></li>
                </ul>
                <ul class="actBox">
                  <li id="act-pus"><a href="javascript:;" onclick="AddFavorite();">收藏</a></li>
                  <li id="act-pnt"><a href="javascript:;" onclick="window.print();">打印</a></li>
                </ul>
            <input type="hidden" name="aid" id="aid" value="61">
            <input type="hidden" name="molds" id="molds" value="1">
        </div>

              <div class="commnum">
                <span>
                  <i>
                  0          </i>
                  条评论
                </span>
              </div>

              <div class="commnet">
                <form name="form" id="form" action="" method="post">
                  <div class="msg">
                    <textarea name="comment" id="comment">说点什么吧...</textarea>
                  </div>
                  <div class="toolbar">
                    <div class="options">
                      不想登录？直接点击发布即可作为游客留言。
                    </div>
                    <button class="button" type="button">发 布</button>
                  </div>
                </form>
              </div>

</div>
</div>
</body>

<!-- /mainbody--> 
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>
<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 16 : intval($cid);
$cid = empty($cid) ? 52: intval($cid);
?>
<!DOCTYPE html UBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="CSS/news.css"/>
<link rel="stylesheet" href="CSS/head-common.css"/>
<link rel="stylesheet" href="CSS/footer-common.css"/>
<link rel="stylesheet" href="CSS/base.css"/>
<link rel="stylesheet" href="CSS/bootstrap.min.css"/>
<script src="JS/jquery.min.js""></script>
<script src="JS/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->

<!-- banner-->
<div class="nav-content">
<div class="container"> 
  <div class="row">
     <div class="col-lg-12 col-md-12">
			<?php
					$dosql->Execute("select * from `#@__infoimg` WHERE classid=13  AND delstate='' AND checkinfo=true ORDER BY orderid DESC limit 0,1");
					while($row = $dosql->GetArray())
					{
						if($row['linkurl'] != '')$gourl = $row['linkurl'];
						else $gourl = 'javascript:;';
					?>
	
	 <div class="nav-img">
                <img src="<?php echo $row['picurl']; ?>" alt="" />
            </div>

               <?php
			         }
			         ?>
         </div>
      </div>
  </div>
</div>

<!-- /banner--> 


<!-- start 导航 -->
	<div class="common">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="common-title">
						<?php echo GetCatName($cid); ?>
						</div>

						<div class="common-content">
						您当前所在位置：<?php echo GetPosStr($cid); ?>
						</div>
							<div class="common-wrap"></div>
			</div>
		</div>
	</div>
</div> 	

<div class="position">
	<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="position-title"><?php echo GetCatName($cid); ?></div>
					<div class="position-wrap"></div>
			</div>
		</div>
	</div>
</div> 
<!-- end 导航位置 -->	

<!--start 内容 -->
<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
				
				<?php
				$dopage->GetPage("SELECT * FROM `#@__infoimg` WHERE classid=20  AND delstate='' AND checkinfo=true ORDER BY orderid ASC");
				while($row = $dosql->GetArray())
				{
					if($row['picurl'] != '') $picurl = $row['picurl'];
					else $picurl = 'templates/default/images/nofoundpic.gif';
					
					if($row['linkurl']=='' and $cfg_isreurl!='Y') $gourl = 'caseshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y') $gourl = 'caseshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else $gourl = $row['linkurl'];

					$r = $dosql->GetOne("SELECT `classname` FROM `#@__infoclass` WHERE id=".$row['classid']);
					if(isset($r['classname'])) $classname = $r['classname'];
					else $classname = '';

					if($cfg_isreurl!='Y') $gourl2 = 'case.php?cid='.$row['classid'];
					else $gourl2 = 'case-'.$row['classid'].'-1.html';
				?>
					
			<div class="one-content">
				<div class="one-image">
						<img src="<?php echo $row['picurl']; ?>" alt=""/>	
					</div>
					<article>
						<h3><a href="<?php echo $gourl; ?>"><?php echo $row['title']; ?></a></h3>
						<h5>时间：<time datetime="2017-03-28">2017-03-28</time></h5>
						<p>
							<?php echo $row['content']; ?>	
						 </p>
					</article>
				</div>
				
					<?php
			         }
			         ?>
		</div>	
	</div>
</div>


<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>
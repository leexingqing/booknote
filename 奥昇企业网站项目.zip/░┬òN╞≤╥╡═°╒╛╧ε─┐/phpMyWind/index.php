﻿
<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>
	<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" href="CSS/index.css"/>
	<link rel="stylesheet" href="CSS/common.css"/>
	<link rel="stylesheet" href="CSS/head-common.css"/>
    <link rel="stylesheet" href="CSS/footer-common.css"/>
	<link rel="stylesheet" href="CSS/bootstrap.min.css"/>
	<script src="JS/jquery.min.js""></script>
	<script src="JS/bootstrap.min.js"></script>
	<script src="JS/index.js"></script>
	<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
	<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
	<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
	<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
	<script type="text/javascript" src="templates/default/js/top.js"></script>
	<script type="text/javascript">
$(function(){
    $(".imgwrap li img").LoadImage({width:60,height:45});
	$(".newsfocus div img").LoadImage({width:60,height:60});
});
</script>
</head>
<body>

<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->

<!--start  轮播图 -->
<div class="nav-content">
	<div class="head-carousel">
		<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12">
						<div id="myCarousel" class="carousel slide">

		<!-- 轮播（Carousel）指标 -->
		<ol class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1"></li>
			<li data-target="#myCarousel" data-slide-to="2"></li>
		</ol>   
		<!-- 轮播（Carousel）项目 -->
		
		<div class="carousel-inner">
			<div class="item active">
				<img src="images/banner1.jpg" alt="First slide">
			</div>
			<div class="item">
				<img src="images/banner2.jpg" alt="Second slide">
			</div>
			<div class="item">
				<img src="images/banner3.jpg" alt="Third slide">
			</div>
		</div>

		<!-- 轮播（Carousel）导航 -->
		  <a class="carousel-control left" href="#myCarousel" data-slide="prev">
	     <img src="images/left-arrow.png" alt=""> 
	    </a>
	    <a class="carousel-control right" href="#myCarousel" 
	        data-slide="next">
	        <img src="images/right-arrow.png" alt="">
	    </a>

			   		</div>
				</div> 
			</div>
		</div>
	</div>
</div>
<!--end 轮播图 -->

<!-- start 解决方案标题 -->
<div class="solution">
	<div class="aorise-title">
		<a href="solution.php">解决方案/solution More </a>
	</div>
	<div class="aorise-wrap"></div>
</div>
<!-- end 解决方案标题 -->

		<div class="s-content">
			<div class="container">
				<div class="row">

				<?php
			$dosql->Execute("SELECT * FROM pmw_infolist WHERE classid= 14  AND delstate='' AND checkinfo=true ORDER BY orderid DESC   LIMIT 0,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>

			<div class="col-lg-4 col-md-4">
				<div class="s-border">
					<div class="s-img">
						<a href="<?php echo $gourl; ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"/></a>
					</div>
					<div class="s-img-title">
						<?php echo $row['title']; ?>
					</div>
				</div>
			</div>  
                    <?php
			         }
			         ?>
				</div>
			</div>		
		</div>

		<!-- /newslist-->

<!-- 关于我们 -->
<div class="aboutus">
		<div class="aorise-title">
			<a href="aboutUs.php">关于我们/about Us</a>
		</div>
		<div class="aorise-wrap"></div>
</div>

<div class="a-content">
	<div class="container">
		<div class="total-hexagon">
			<div class="row">


			<?php
			$dosql->Execute("SELECT * FROM pmw_infolist WHERE classid=15  AND delstate='' AND checkinfo=true ORDER BY orderid DESC   LIMIT 1,5");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>

				<div class="col-lg-3 col-md-3">
					<div class="hexagon-context">
						<div class="hexagon">
							<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"/>
							<h4><a href="#"><?php echo $row['title']; ?></a></h4>
						</div>
					</div>
					</div>

				<?php
			         }
			         ?>

			</div>
		</div>
	</div>
</div>
<!-- end 关于我们 -->

<!-- 新闻资讯 -->
<div class="news">
	<div class="aorise-title">
			<a href="news.php">新闻资讯/NEWS MOre</a>
	</div>
	<div class="aorise-wrap"></div>
</div>


<div class="container">
	<div class="row">
		<div class="col-lg-6 col-md-6">
		<?php
			$dosql->Execute("SELECT * FROM pmw_infolist WHERE classid=15  AND delstate='' AND checkinfo=true ORDER BY orderid DESC   LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>

			<a href="newsshow.php"><img src="<?php echo $row['picurl']; ?>" alt="" ></a>
			<?php echo $row['content']; ?>
			</div>

					<?php
			         }
			         ?>

		<div class="col-lg-6 col-md-6">

						<?php
							$dosql->Execute("SELECT * FROM pmw_infolist WHERE classid=16  AND delstate='' AND checkinfo=true ORDER BY orderid asc LIMIT 0,7");
							while($row = $dosql->GetArray())
							{
								if($row['linkurl'] != '')$gourl = $row['linkurl'];
								else $gourl = 'javascript:;';
							?>
								<ul>
									<div class="n-triangle"></div>
									<li>
										<a href="#"><?php echo $row['title']; ?><time datetime="2017年6月18日">2017-6-18</time></a>
									</li>

							</ul>
								<?php
							         }
							         ?>
		</div>
	</div>
</div>

</div>
</div>



<!-- 底部 -->
<?php require_once('footer.php'); ?>

<!-- 底部 -->
</body>
</html>
